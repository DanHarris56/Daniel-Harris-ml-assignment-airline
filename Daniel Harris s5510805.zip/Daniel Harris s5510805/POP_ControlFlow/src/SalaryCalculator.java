/**
 * SalaryCalculator class - part of Control Flow
 * Selection and Iteration examples
 * @author Dr Suzy Atfieldcutts adapted from Melanie Coles
 * @since 2020
 */

public class SalaryCalculator {

	//Task 1
	 public double salaryTax(double grossSalary) {
         double netSalary;
         if (grossSalary >= 45000) {
             netSalary = grossSalary * .5;
         }
         else if (grossSalary >= 30000) {
             netSalary = grossSalary * .7;
         }
         else {
             netSalary = grossSalary * .85;
         }
         return netSalary;
	}

	//Task 2
	public double calculateNI(double grossSalary, Character niBand) {
         niBand = Character.toUpperCase(niBand);
         double ni;
		 switch (niBand) {
             case 'A': ni = 0.88; break;
             case 'B': ni = 0.9415; break;
             case 'C': ni = 0.98; break;
             default: ni = 1.0; break;
         }
         return grossSalary * ni;



	}
	
	//Task 3
	 public double salaryTotal(double[] salaries) {
		double total = 0.0;
         for (double salary: salaries) {
             total += salary;
         }
        return total;
	}

	// Task 4
	 public double salaryAverage(double[] salaries) {
        double total = 0.0;
         for (double salary: salaries) {
             total += salary;
         }
        return total / salaries.length;
	}

	//Task 5
	 public double[] salaryIncrease(double[] salaries) {
         for (int i = 0; i < salaries.length; i++) {
             salaries[i] = salaries[i] + 0.05 * salaries[i];
         }
         return salaries;
	}
}
