import java.util.Random;
/**
 * LabExample class - part of Control Flow
 * Selection and Iteration examples
 * @author Dr Suzy Atfieldcutts adapted from Melanie Coles
 * @since 2020
 */
public class LabExample {

		// Task 1
		 public int highestOfTwo(int num1, int num2) {
             int result = -1;
             if (num1 > num2) {
                 result = num1;
             }
             else if (num2 > num1) {
                 result = num2;
             }
             return result;
		}
	
		// Task 2
		 public String calculateGrade(int score) {
             String result;
            if (score < 0 || score > 100) {
                result =  "Invalid mark";
            }
            else if (score < 40) {
                result = "Fail";
            }
            else if (score < 50) {
                result = "3rd";
            }
            else if (score < 60) {
                result = "2ii";
            }
            else if (score < 70) {
                result = "2i";
            }
            else {
                result = "1st";
            }
            return result;
		}
		
		// Task 3
		 public String headsOrTails(String guess) {
			double flip = Math.random();
            String result;
            String statement;
            if (flip >= 0.5) {
                result = "heads";
            }
            else {
                result = "tails";
            }
            if (result.equals(guess)) {
                statement = "Correct: you guessed " + guess + " and I flipped " + result;
            }
            else {
                statement = "Incorrect: you guessed " + guess + " and I flipped " + result;
            }
            return statement;
		}
		
		// Task 4
		 public int sumFromOneToWhat(int top) {
			int sum = 0;
            for (int i = 1; i < top + 1; i++) {
                 sum += i;
            }
            return sum;
         }
		
		// Task 5
		public int sumFromWhatToWhat(int bottom, int top) {
            int sum = 0;
            for (int i = top - bottom; i >= 0; i --) {
                sum += top;
                top --;
            }
            return sum;
		}
}
