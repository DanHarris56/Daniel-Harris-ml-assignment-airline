import java.util.Arrays;
import java.util.Locale;
import java.util.Random;
/**
 * WordPlayStudentOuputTests class - part of Control Flow
 * Advanced String manipulation tasks examples
 * @author Dr Suzy Atfieldcutts adapted from Melanie Coles
 * @since 2020
 */
public class WordPlay {

    //Task1
    public String whatComesFirst(String word1, String word2) {
        String[] words = {word1.toLowerCase(), word2.toLowerCase()};
        if (words[0].equals(words[1])) {
            return words[0] + " is the same as " + words[0];
        } else {
            Arrays.sort(words);
            return words[0] + " comes before " + words[1] + " in the alphabet";
        }
    }

    //Task 2
	public String backwardsString(String stringIn) {
        StringBuilder stringBackwards = new StringBuilder();
        for (int i = stringIn.length() - 1; i > -1; i--) {
            stringBackwards.append(stringIn.charAt(i));
        }
		return stringBackwards.toString();
	}

    //Task 3
	public String[] addressBook(String[] names, String[] numbers) {
        String[] book = new String[3];
		for (int i = 0; i < names.length; i ++) {
            book[i] = names[i] + " " + numbers[i];
        }
		return book;
	}

        //Task 4
	public String rockPaperScissors(String userChoice) {
        userChoice = userChoice.toLowerCase();
        String[] rps = {"rock", "paper", "scissors"};
        String computerChoice = rps[(int) (Math.random() * 3)];
        String result;
        if (userChoice.equals(computerChoice)) {//checks for a draw
            result = " it is a draw";
        }
        else if (userChoice.equals("rock")) {//if user picks rock
            if (computerChoice.equals("paper")) {//and comp picks paper
                result = " COMPUTER wins";
            }
            else {//or comp picks scissors
                result = " user wins";
            }
        }
        else if (userChoice.equals("paper")) {//if user picks paper
            if (computerChoice.equals("scissors")) {//and comp picks scissors
                result = " COMPUTER wins";
            }
            else {//or comp picks rock
                result = " user wins";
            }
        }
        else {//if comp picks scissors
            if (computerChoice.equals("rock")) {//and comp pics rock
                result = " COMPUTER wins";
            }
            else {//or comp picks paper
                result = " user wins";
            }
        }
        return "USER:" + userChoice + " vs COMP:" + computerChoice + result;
    }
}


