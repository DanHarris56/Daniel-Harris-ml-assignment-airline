
public class Dice {
    protected int faceValue = 0;

	//Task 1
	public void roll() {
		faceValue = (int)(Math.random() * 6 + 1);//creates a random double from 0 to less than 6, adds 1, then truncates the double to an integer
	}

	//Task 1 - second bit
	public int getFaceValue() {
		return faceValue;
	}

	//Task 2
	public String toString() {
		return Integer.toString(faceValue);
	}
}
