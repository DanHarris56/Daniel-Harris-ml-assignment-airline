public class CrapsStudentOutputTests {

    public static void main(String[] args) {
        Craps craps = new Craps();

        //Task 1
        //System.out.println("Dice1: "+craps.getDice1().getFaceValue());
        //System.out.println("Dice2: "+craps.getDice2().getFaceValue());

        //Task 2
        //System.out.println("Score is "+ craps.addUpScore());

        //Task 3
        //System.out.println("Outcome: "+craps.decideOutcome(craps.addUpScore()));

        //Task 4
        //System.out.println(craps.getResults());

        //Task 5
        System.out.println(craps.playCraps());

        //Task 6
        //craps.playAgain();

    }

}
