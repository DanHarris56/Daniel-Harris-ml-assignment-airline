import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class ProcessNames {

	//Task 1 - read in all data from a file
	public ArrayList<String> readNames(String fileName) throws Exception {
		Scanner fileReader = new Scanner(new File(fileName));
		ArrayList<String> names = new ArrayList<>();
        while (fileReader.hasNextLine()) {
            names.add(fileReader.nextLine());
        }
        return names;
	}

	//Task 2 - sort the data
	public ArrayList<String> sortNames(ArrayList<String> nameList){
	    Collections.sort(nameList);
        return nameList;
	}

	//Task3 - find name position
	public int findNamePosition(ArrayList<String> nameList, String name) {
		int pos = -1;
		for (int i=0; i < nameList.size(); i++) {
		    if (nameList.get(i).equals(name)) {
		    	pos = i;
            }
        }
        return pos;
	}

	//Task4 - delete name
	public ArrayList<String> deleteName(ArrayList<String> nameList, String name){
		nameList.remove(name);
		return nameList;
	}



	//Task5 - change name
	public ArrayList<String> changeName(ArrayList<String> nameList, String oldName, String newName){
		nameList.set(findNamePosition(nameList, oldName), newName);
		return nameList;
	}


}