public class Craps {
    public static Dice dice1 = new Dice();
    public static Dice dice2 = new Dice();

	//Task 1
	public void shoot() {
		dice1.roll();
		dice2.roll();
	}

	//Task 1
	public Dice getDice1() {
		return dice1;
	}

	//Task 1
	public Dice getDice2() {
		return dice2;
	}

	//Task 2
	public int addUpScore() {
		return dice1.getFaceValue() + dice2.getFaceValue();
	}

	//Task 3
	public String decideOutcome(int score) {
		String result;
		if (score == 7 || score == 11) {
			result = "You win";
		}
		else if (score == 2|| score == 3|| score == 12) {
			result = "You lose";
		}
		else {
			result = "Throw again";
		}
		return result;
	}

	//Task 4 - No UNIT TEST FOR THIS ONE - Check the output
	public String getResults() {
		return "Dice 1 is " + dice1.toString() +
				"\nDice 2 is " + dice2.toString() +
				"\nTotal is: " + addUpScore() +
				"\nResult is " + decideOutcome(addUpScore());//spread over multiple lines for readability
	}

	//Task 5 - No UNIT TEST FOR THIS ONE - Check the output
	public String playCraps() {
		String game = "";
		do {
			shoot();//rolls dice
			game = game + "\n" + getResults() + "\n**************";//adds the game onto the previous games with separator

		} while (decideOutcome(addUpScore()).equals("Throw again"));//checks if the player can Throw again
		return game;//returns the whole game as one String
	}
}
