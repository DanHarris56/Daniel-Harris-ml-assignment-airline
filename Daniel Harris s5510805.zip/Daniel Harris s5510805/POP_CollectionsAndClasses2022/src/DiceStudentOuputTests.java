public class DiceStudentOuputTests{

    public static void main(String[] args) {
        //Create the Dice
        Dice dice = new Dice();

        //Task 1
        //System.out.println("Dice facevalue: "+dice.getFaceValue());
        //dice.roll();
        //System.out.println("Dice facevalue: "+dice.getFaceValue());

        //Task 2
        //System.out.println("Dice object "+dice);
    }
}
