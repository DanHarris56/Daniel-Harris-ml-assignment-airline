/**
 * UserInputStudentOutputTask1 class - part of POP_ReadingAndWriting_STAFF
 * A main method for student tests using output to the screen, for File reading and writing, and user input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class UserInputStudentOutputTask1 {

	public static void main(String[] args) {
		UserInput userInput = new UserInput();

		//Task 1
		System.out.println(userInput.sayHello());
	}
}