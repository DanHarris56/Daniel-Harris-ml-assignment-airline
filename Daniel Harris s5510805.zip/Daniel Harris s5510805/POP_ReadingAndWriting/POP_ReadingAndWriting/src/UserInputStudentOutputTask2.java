import java.util.Arrays;
/**
 * UserInputStudentOutputTask2 class - part of POP_ReadingAndWriting_STAFF
 * A main method for student tests using output to the screen, for File reading and writing, and user input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class UserInputStudentOutputTask2 {

	public static void main(String[] args) {
		UserInput userInput = new UserInput();
		//Task 2
		System.out.println(Arrays.toString(userInput.readTenNumbers()));
	}
}