import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
/**
 * FileWriting class - part of POP_ReadingAndWriting_STAFF
 * File reading and writing, and User input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */
public class FileWriting {

	//Task 1
	/*public ?? writeYourName(??) throws Exception {
		return ??;
	}*/
	
	//Task 2
	/*public ?? writeRandomNumbers(??) throws Exception {
		return ??;
	}*/

}
