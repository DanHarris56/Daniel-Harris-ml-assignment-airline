import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileNotFoundException;
/**
 * FileReading class - part of POP_ReadingAndWriting_STAFF
 * File reading and writing, and User input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class  FileReading {

	//Task 1
	 public String readName1(String file) throws Exception {
		Scanner fileReader = new Scanner(file);
		String firstName = fileReader.nextLine();
		String secondName = fileReader.nextLine();
		fileReader.close();
		return firstName + " " + secondName;
	}

	//Task 2
	/*public ?? readName2(??) throws Exception {
		return ??;
	}*/

	//Task 3
	/*public ?? readNames(??) throws Exception {
		return ??;
	}*/

	//Task 4
	/*public ?? readNumbers1(??) throws Exception {
		return ??;
	}*/

	//Task5
	/*public ?? readNumbers2(??) throws Exception {
		return ??;
	}*/

	//Task 6
	/*public ?? readAddressBook(??) throws Exception {
		return ??;
	}*/
}
