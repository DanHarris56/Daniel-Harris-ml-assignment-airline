import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;
import java.util.Scanner;
/**
 * FileWriting class - part of POP_ReadingAndWriting_STAFF
 * File reading and writing, and User input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */
public class FileWriting {

	//Task 1
	public String writeYourName(String fullName) throws Exception {
		try {
			PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter("mynamefile.txt")));//Creates new printWriter
			String[] names = fullName.split(" ");//Splits argument into an array of names
			for (String name:names) {//for each name
				printWriter.println(name);
			}
			printWriter.close();//closes the file
		}
		catch (Exception e) {
			return "an error occurred";
		}
		return "mynamefile.txt";
	}

	//Task 2
	public String writeRandomNumbers(int amount) throws Exception {
		try {
			PrintWriter printWriter = new PrintWriter(new BufferedWriter(new FileWriter("randomNumbersFile.txt")));//Creates new printWriter
			for (int i = 0; i < amount; i++) {
				printWriter.println((int)(Math.random()*8999)+1000);//prints random int from 0 to 9999
			}
			printWriter.close();
		}
		catch (Exception e) {
			return "an error occurred";
		}
		return "randomNumbersFile.txt";
	}

}
