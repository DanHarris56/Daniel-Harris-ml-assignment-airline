import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.io.FileNotFoundException;
/**
 * FileReading class - part of POP_ReadingAndWriting_STAFF
 * File reading and writing, and User input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class  FileReading {

	//Task 1
	 public String readName1(String fileName) throws Exception {
		Scanner fileReader = new Scanner(new File(fileName));
		String firstName = fileReader.next();
		String secondName = fileReader.next();
		fileReader.close();

		return firstName + " " + secondName;
	}

	//Task 2
	public  String readName2(String fileName) {
		try {
			Scanner fileReader = new Scanner(new File(fileName));
			String firstName = fileReader.nextLine();
			String secondName = fileReader.nextLine();
			fileReader.close();
			return firstName + " " + secondName;
		}
		catch (Exception e) {
			return "Invalid filename";
		}
	}

	//Task 3
	public String[] readNames(String fileName) throws Exception {
		Scanner fileReader = new Scanner(new File(fileName));
		String[] tenNames = new String[10];
		for (int i = 0; i < 10; i++) {
			tenNames[i] = fileReader.nextLine();;
		}
		return tenNames;
	}

	//Task 4
	public int[] readNumbers1(String fileName) throws Exception {
	 	File numbers = new File((fileName));
		Scanner fileReader = new Scanner(numbers);
		int[] numArray = new int[20];
		for (int i = 0; fileReader.hasNext(); i++) {
			numArray[i] = Integer.parseInt(fileReader.nextLine());
		}
		fileReader.close();
		return numArray;
	}

	//Task5
	public int[] readNumbers2(String fileName) throws Exception {
		File numbers = new File(fileName);
		Scanner fileReader = new Scanner(numbers);
		int[] numArray = new int[20];
		for (int i = 0; fileReader.hasNext(); i++) {
			if (fileReader.hasNextInt()) {
				numArray[i] = Integer.parseInt(fileReader.nextLine());
			}
			else {
				fileReader.nextLine();
				i--;
			}
		}
		fileReader.close();
		return numArray;
	}

	//Task 6
	public String[] readAddressBook(String fileName) throws Exception {
		File addresses = new File(fileName);
		Scanner fileReader = new Scanner(addresses);
		String[] addressBook = new String[5];
		for (int i = 0; fileReader.hasNext(); i++) {
			addressBook[i] = fileReader.nextLine() + ": " + fileReader.nextLine();
		}
		fileReader.close();
		return addressBook;
	}
}
