import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
/**
 * UserInput class - part of POP_ReadingAndWriting_STAFF
 * File reading and writing, and User input tasks
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class UserInput {
	//Task 1
	public String sayHello() {
        Scanner input = new Scanner(System.in);
        System.out.println("Hi, what's your name?: ");
        return "Hello " + input.nextLine();
	}

	//Task 2
	public int[] readTenNumbers() {
		Scanner input = new Scanner(System.in);
		int[] tenNumbers = new int[10];
		System.out.println("Enter 10 numbers: ");

		for (int i = 0; i < 10; i++) {
			String inputStr;
			inputStr = input.nextLine();
			tenNumbers[i] = Integer.parseInt(inputStr);
		}
		return tenNumbers;
	}

	//Task 3
	 public String[] readTenNames() {
		Scanner input = new Scanner((System.in));
		String[] tenNames = new String[10];
		System.out.println("Enter 10 Names: ");

		for (int i = 0; i < 10; i++) {
			tenNames[i] = input.nextLine();
		}
		return tenNames;
	}
}
