/**
 * Names class
 * This class contains tasks related to the use of the Strings class.
 *
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class Names {

	// Task 1
	 public String upperCaseName(String name) {
		return name.toUpperCase();
	}

	// Task 2

	 public String fullName(String firstName, String secondName) {
		return firstName+" "+secondName;
	}

	// Task 3

	 public Integer  letterCount(String name) {
		return name.length();
	}

	// Task 4
	 public Boolean  theSameName(String name1, String name2) {
         name1 = name1.toUpperCase();
         name2 = name2.toUpperCase();
         return name1.equals(name2);
	}

	// Task 5
	 public String properCaseName(String name) {
         return Character.toUpperCase(name.charAt(0))+ name.substring(1).toLowerCase();
	}
}
