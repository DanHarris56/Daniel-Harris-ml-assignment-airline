import java.text.DecimalFormat;

/**
 * Salary class
 * This class contains tasks about calculating salaries.
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class Salary {

	 //Task 1
  	 public Integer salaryIncrease(int salary) {
  		 return salary+200;
	}

	// Task 2
	 public Double salaryIncrease(double salary) {
		return salary+200.5;
	}

	// Task 3:
	 public Double salaryIncrease(double salary, int percent) {
		return (percent*1.0/100+1)*salary;
	}

	// Task 4
	 public Double calculatePay(double salary) {
		return (salary-(salary*0.13)-(salary*0.15))/12;
	}

	// Task 5 - this one is more of a challenge - you can come back to it later
	 public String formatCurrency(double salary) {
		return "£"+ new DecimalFormat("###,###,##0.00").format(salary);
	}
}
