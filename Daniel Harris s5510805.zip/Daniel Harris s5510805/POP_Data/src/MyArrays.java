import com.sun.source.tree.ReturnTree;

import java.lang.reflect.Array;
import java.util.Random;

/**
 * MyArrays class
 * This class contains tasks about using arrays.
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */

public class MyArrays {

	// Task 1
	 public Integer addUpNumbers(int num1, int num2, int num3, int num4, int num5) {
		return num1 + num2 + num3 + num4 +num5;
	}

	// Task 2
	 public Integer addUpNumbers(int[] numbers) {
		 int numbersAddedUp = 0;
		 for (int i = 0; i < 5; i++) {
			 numbersAddedUp = numbersAddedUp + numbers[i];
		 }
		 return numbersAddedUp;
	}

	// Task 3
	 public Double averageOfNumbers(int[] numbers) {
		 int numbersAddedUp = 0;
		 for (int i = 0; i < 5; i++) {
			 numbersAddedUp = numbersAddedUp + numbers[i];
		 }
		 return (numbersAddedUp+0.0)/5;

	}

	// Task 4
	 public int[] convertToCelsius(int[] numbers) {
		 for (int i = 0; i < 5; i++) {
			 numbers[i] = (numbers[i]-32)*5/9;
		 }
		 return numbers;
	}

	// Task 5
	 public String[] unitMarks(int[] gradesInput) {
		 String[] gradesOutput = {"","","","","","",""};
		 gradesOutput[0] = "APP:"+gradesInput[0];
		 gradesOutput[1] = "BSAD:"+gradesInput[1];
		 gradesOutput[2] = "CF:"+gradesInput[2];
		 gradesOutput[3] = "DAD:"+gradesInput[3];
		 gradesOutput[4] = "N&CS:"+gradesInput[4];
		 gradesOutput[5] = "POP:"+gradesInput[5];
		 int average = 0;
		 for (int i = 0; i < 6; i++) {
			 average = average + gradesInput[i];
		 }
		 gradesOutput[6] = "Average:"+ (average+0.0)/6;
		 return gradesOutput;
	}

	// Task 6
	 public String andTheWinnerIs(String[] names) {
		 int rng = (int) (Math.random() * names.length);
		 return names[rng];
	}
}
