/**
 * NamesStudentOutputTests class
 * YOU SHOULD EDIT THIS CLASS to run the methods of the Names class and produce output.
 * @author Dr Suzy Atfield-Cutts adapted from Melanie Coles
 * @since 2020
 */
public class NamesStudentOutputTests {

    public static void main(String[] args) {
        Names names = new Names();

        System.out.println("Upper case name is "+names.upperCaseName("boris")); // Task 1
        System.out.println("Full name is "+names.fullName("Alison", "Jones")); // Task 2
        System.out.println("Count of letters in the name "+names.letterCount("Melanie")); // Task 3
        System.out.println("Are the names the same "+names.theSameName("Donald", "Donald")); // Task 4
        System.out.println("Proper case name is "+names.properCaseName("mATTHEW")); // Task 5
    }
}
